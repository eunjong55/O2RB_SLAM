#include <iostream>
#include <algorithm>
#include <fstream>
#include <chrono>
#include <iomanip>

#include <opencv2/opencv.hpp>
#include "System.h"

using namespace std;
using namespace cv;

typedef Point3f Cartesian;

///   sphere axis
struct Sphere
{
    float radius; ///< sphere radius
    float theta;  ///< sphere theta
    float phi;    ///< sphere phi
};

/// intrinsic parameters
struct Intrinsic
{
    Point2f principalPoint; ///< same as optical center (offset)
    float focalLengthPixel; ///< focal length (in pixel)
    struct
    {
        int nDegree;        ///< degree of polynomial function
        float polyCoeff[9]; ///< coefficients of polynomial function
    } forward, backward;
};

///   convert a point on distorted image into undistorted sphere coordinates
bool convertFisheye2Sphere(const    Cartesian   &cartesian, ///< a source point in cartesian coordinates
                                    Sphere      &sphere,             ///< a target point in sphere coordinates
                           const    Intrinsic   &intrinsic); ///< intrinsic parameters
///   convert a point on undistorted world plane into on distorted image plane
bool convertSphere2Fisheye(const    Sphere      &sphere,       ///< a source point in sphere coordinates
                                    Cartesian   &cartesian,       ///< a targe point in cartesian coordinates
                           const    Intrinsic   &intrinsic); ///< intrinsic parameters
///sphere to 2d pinhole image
bool convertSphere2Pinhole(const    Sphere      &sphere,
                                    Cartesian   &cartesian);
///pinhole image to sphere
bool convertPinhole2Sphere(const    Cartesian   &cartesian,
                                    Sphere      &sphere);

int radius;

int main(int argc, char **argv)
{
    Intrinsic intrinsic;

    intrinsic.principalPoint = Point2f(0, -2.95473);
    intrinsic.focalLengthPixel = 238;
    intrinsic.forward.nDegree = 6;
    intrinsic.forward.polyCoeff[0] = 2e-005;
    intrinsic.forward.polyCoeff[1] = 1.0043;
    intrinsic.forward.polyCoeff[2] = 0.0009;
    intrinsic.forward.polyCoeff[3] = -0.009;
    intrinsic.forward.polyCoeff[4] = -0.0027;
    intrinsic.forward.polyCoeff[5] = 0.0028;
    intrinsic.forward.polyCoeff[6] = -0.0009;
    intrinsic.forward.polyCoeff[7] = 0.f;
    intrinsic.forward.polyCoeff[8] = 0.f;

    intrinsic.backward.nDegree = 6;
    intrinsic.backward.polyCoeff[0] = 0.0005;
    intrinsic.backward.polyCoeff[1] = 0.9798;
    intrinsic.backward.polyCoeff[2] = 0.0843;
    intrinsic.backward.polyCoeff[3] = -0.1651;
    intrinsic.backward.polyCoeff[4] = 0.1662;
    intrinsic.backward.polyCoeff[5] = -0.0743;
    intrinsic.backward.polyCoeff[6] = 0.0129;
    intrinsic.backward.polyCoeff[7] = 0.f;
    intrinsic.backward.polyCoeff[8] = 0.f;

    radius = 100;

    string path_to_vocabulary = "/home/jeenq/Google_Drive/ORB_SLAM2/Vocabulary/ORBvoc.txt";
    string path_to_settings = "/home/jeenq/Google_Drive/ORB_SLAM2/Examples/Monocular/undistorted_vadas_fisheye.yaml";

    VideoCapture cap("/home/jeenq/Dataset/vadas_fisheye_parking_dataset/P-001/ch01.mp4");
    if (!cap.isOpened())
    {
        cerr << "Cannot open camera." << endl;
        return -1;
    }
    double delay = 1000 / cap.get(CV_CAP_PROP_FPS);
    int start = 1000;
    cap.set(CV_CAP_PROP_POS_FRAMES, start);

    cv::Mat mask = imread("/home/jeenq/Google_Drive/ORB_SLAM2/Examples/Monocular/undistorted_vadas_fiseye_mask.png", IMREAD_GRAYSCALE);
    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    // ORB_SLAM2::System SLAM(path_to_vocabulary,path_to_settings,ORB_SLAM2::System::MONOCULAR,true);
    ORB_SLAM2::System SLAM(path_to_vocabulary,path_to_settings,ORB_SLAM2::System::MONOCULAR,true,mask); 
    // Addition : Mask compatible

    // Main loop
    cv::Mat frame;

    while(true)
    {
        // Read image from file
        cap >> frame;

        if(frame.empty())
        {
            cerr << endl << "Failed to read camera" << endl;
            return 1;
        }

        Mat pinhole = Mat::zeros(Size(800, 400), CV_8UC3);

        uchar* pinhole_data = pinhole.data;
        uchar* frame_data = frame.data;

        for(int y=0; y<pinhole.rows; y++){
            for(int x=0; x<pinhole.cols; x++){
                Sphere temp_sphere;
                Cartesian temp_cartesian(x-pinhole.cols/2, y-pinhole.rows/2, 1);
                convertPinhole2Sphere(temp_cartesian, temp_sphere);
                convertSphere2Fisheye(temp_sphere, temp_cartesian, intrinsic);
                int x_ = int(temp_cartesian.x) + frame.cols/2;
                int y_ = int(temp_cartesian.y) + frame.rows/2;
                if((x_>=0 && x_<frame.cols) && (y_>=0 && y_<frame.rows)){
                    pinhole_data[y * pinhole.cols * 3 + x * 3 + 0] = frame_data[y_ * frame.cols * 3 + x_ * 3 + 0];
                    pinhole_data[y * pinhole.cols * 3 + x * 3 + 1] = frame_data[y_ * frame.cols * 3 + x_ * 3 + 1];
                    pinhole_data[y * pinhole.cols * 3 + x * 3 + 2] = frame_data[y_ * frame.cols * 3 + x_ * 3 + 2];
                    // pinhole.at<Vec3b>(y, x) = frame.at<Vec3b>(y_, x_);
                }
            }
        }

        // Pass the image to the SLAM system
        SLAM.TrackMonocular(pinhole, delay);
    }

    // Stop all threads
    SLAM.Shutdown();

    // Save camera trajectory
    SLAM.SaveKeyFrameTrajectoryTUM("KeyFrameTrajectory.txt");    

    return 0;
}

///   convert a point on distorted image into undistorted sphere coordinates
bool convertFisheye2Sphere(const    Cartesian   &cartesian, ///< a source point in cartesian coordinates
                                    Sphere      &sphere,             ///< a target point in sphere coordinates
                           const    Intrinsic   &intrinsic) ///< intrinsic parameters
{
    Point2f distortPt;
    distortPt.x = cartesian.x - intrinsic.principalPoint.x; /// apply principal point
    distortPt.y = cartesian.y - intrinsic.principalPoint.y; /// apply principal point

    /// change distance domain from pixel to mm
    float rd = sqrt(pow(distortPt.x, 2) + pow(distortPt.y, 2)) / intrinsic.focalLengthPixel;

    // polynomial function
    float ruPoly = 0.f;
    for (int i = 0; i <= intrinsic.backward.nDegree; i++)
    {
        ruPoly += intrinsic.backward.polyCoeff[i] * pow(rd, i);
    }

    /// output
    sphere.theta = ruPoly / intrinsic.focalLengthMm;
    sphere.radius = radius; /// any value
    sphere.phi = atan2(distortPt.y, distortPt.x);

    return true;
}

///   convert a point on undistorted world plane into on distorted image plane
bool convertSphere2Fisheye(const    Sphere      &sphere,       ///< a source point in sphere coordinates
                                    Cartesian   &cartesian,       ///< a targe point in cartesian coordinates
                           const    Intrinsic   &intrinsic) ///< intrinsic parameters
{
    float ru = intrinsic.focalLengthMm * sphere.theta;

    // polynomial function
    float rdPoly = 0.f;
    for (int d = 0; d <= intrinsic.forward.nDegree; d++)
    {
        rdPoly += (intrinsic.forward.polyCoeff[d] * pow(ru, d));
    }
    float rd = rdPoly * intrinsic.focalLengthPixel;

    cartesian.x = rd * cos(sphere.phi) + intrinsic.principalPoint.x;
    cartesian.y = rd * sin(sphere.phi) + intrinsic.principalPoint.y;

    return true;
}

///sphere to 2d pinhole image
bool convertSphere2Pinhole(const    Sphere      &sphere,
                                    Cartesian   &cartesian)
{
    // cartesian.x = sphere.radius * sin(sphere.phi) * cos(sphere.theta);
    // cartesian.y = sphere.radius * sin(sphere.phi) * sin(sphere.theta);
    if(sphere.theta > 0 && sphere.theta < M_PI/2){
        cartesian.x = sphere.radius * tan(sphere.theta) * cos(sphere.phi);
        cartesian.y = sphere.radius * tan(sphere.theta) * sin(sphere.phi);
        // cartesian.z = sphere.radius * cos(sphere.phi);
        cartesian.z = 1;

        return true;
    }
    else{
        return false;
    }
}

///sphere to 2d pinhole image
bool convertPinhole2Sphere(const    Cartesian   &cartesian,
                                    Sphere      &sphere)
{
    sphere.phi = atan2(cartesian.y, cartesian.x);
    float r = sqrt(pow(cartesian.x, 2) + pow(cartesian.y, 2));
    sphere.theta = atan2(r, radius);
    sphere.radius = radius;

    return true;
}